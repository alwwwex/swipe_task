var struct_s_cn_s_c_b___type =
[
    [ "ACTLR", "struct_s_cn_s_c_b___type.html#aacadedade30422fed705e8dfc8e6cd8d", null ],
    [ "ICTR", "struct_s_cn_s_c_b___type.html#ad99a25f5d4c163d9005ca607c24f6a98", null ],
    [ "RESERVED0", "struct_s_cn_s_c_b___type.html#afe1d5fd2966d5062716613b05c8d0ae1", null ]
];